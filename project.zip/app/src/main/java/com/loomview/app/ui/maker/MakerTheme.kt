package com.loomview.app.ui.maker

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.loomview.app.data.datastore.AppLanguage
import com.loomview.app.data.datastore.AppTheme
import com.loomview.app.data.datastore.SettingsDataStore
import com.loomview.app.ui.theme.LoomviewTheme

/** Same theme wiring the original screens use (theme + language from Settings). */
@Composable
fun MakerTheme(settings: SettingsDataStore, content: @Composable () -> Unit) {
    val appTheme by settings.appTheme.collectAsState(initial = AppTheme.SYSTEM)
    val appLanguage by settings.appLanguage.collectAsState(initial = AppLanguage.SYSTEM)
    LoomviewTheme(appTheme = appTheme, appLanguage = appLanguage, content = content)
}
