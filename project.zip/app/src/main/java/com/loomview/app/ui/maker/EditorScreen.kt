package com.loomview.app.ui.maker

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/**
 * Controls panel under the live preview. All edits go through EditorViewModel; the Activity
 * watches the state and pushes changes into the preview WebView.
 * (New screens are English-only for now; the original Loomview screens stay translated.)
 */
@Composable
fun EditorPanel(
    state: EditorState,
    vm: EditorViewModel,
    onPickBackground: () -> Unit,
    onPickLayer: () -> Unit,
    onReplaceLayer: (String) -> Unit,
    onPickFont: () -> Unit,
    onSave: () -> Unit,
    onExport: () -> Unit,
    onApply: () -> Unit,
) {
    var tab by remember { mutableStateOf(0) }
    val titles = listOf("Background", "Layers", "Clock", "Motion")

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedButton(onClick = onSave, enabled = !state.busy, modifier = Modifier.weight(1f)) {
                    Text("Save")
                }
                OutlinedButton(onClick = onExport, enabled = !state.busy, modifier = Modifier.weight(1f)) {
                    Text("Export")
                }
                Button(onClick = onApply, enabled = !state.busy, modifier = Modifier.weight(1.6f)) {
                    Text("Apply Wallpaper")
                }
            }
            if (state.busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                titles.forEachIndexed { i, title ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
                }
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                when (tab) {
                    0 -> BackgroundTab(state, vm, onPickBackground)
                    1 -> LayersTab(state, vm, onPickLayer, onReplaceLayer)
                    2 -> ClockTab(state, vm, onPickFont)
                    else -> MotionTab(state, vm)
                }
            }
        }
    }
}

@Composable
private fun BackgroundTab(state: EditorState, vm: EditorViewModel, onPick: () -> Unit) {
    val p = state.project
    var name by remember(p.id) { mutableStateOf(p.name) }
    OutlinedTextField(
        value = name,
        onValueChange = { v ->
            name = v
            vm.edit { pr -> pr.copy(name = v.take(60)) }
        },
        label = { Text("Wallpaper name") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onPick) {
            Text(if (p.bgFile == null) "Choose background image" else "Change image")
        }
        if (p.bgFile != null) {
            OutlinedButton(onClick = { vm.clearBackground() }) { Text("Remove") }
        }
    }
    ColorField("Background color (shown behind or without an image)", p.bgColor) { c ->
        vm.edit { it.copy(bgColor = c) }
    }
    LabeledSlider("Zoom", p.bgZoom, 1f..1.8f) { v -> vm.edit { it.copy(bgZoom = v) } }
    LabeledSlider("Focus left-right", p.bgFocusX, 0f..1f, ::percent) { v -> vm.edit { it.copy(bgFocusX = v) } }
    LabeledSlider("Focus up-down", p.bgFocusY, 0f..1f, ::percent) { v -> vm.edit { it.copy(bgFocusY = v) } }
    LabeledSlider("Depth (how much the background moves)", p.bgDepth, 0f..1f) { v ->
        vm.edit { it.copy(bgDepth = v) }
    }
}

@Composable
private fun LayersTab(
    state: EditorState,
    vm: EditorViewModel,
    onAdd: () -> Unit,
    onReplace: (String) -> Unit,
) {
    val p = state.project
    Button(onClick = onAdd) { Text("Add PNG layer") }
    if (p.layers.isEmpty()) {
        Text(
            "No layers yet. Add a transparent PNG (for example a cut-out subject) to place it in front of the background.",
            style = MaterialTheme.typography.bodyMedium,
        )
    } else {
        Text("Top of the list is the front-most layer.", style = MaterialTheme.typography.bodySmall)
    }
    p.layers.asReversed().forEach { layer ->
        val selected = layer.id == state.selectedLayerId
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                .clickable { vm.selectLayer(layer.id) }
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                layer.name,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            IconButton(onClick = { vm.moveLayer(layer.id, 1) }) {
                Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Move forward")
            }
            IconButton(onClick = { vm.moveLayer(layer.id, -1) }) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Move back")
            }
            IconButton(onClick = { vm.editLayer(layer.id) { it.copy(visible = !it.visible) } }) {
                Icon(
                    if (layer.visible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                    contentDescription = "Show or hide",
                )
            }
            IconButton(onClick = { vm.removeLayer(layer.id) }) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete layer")
            }
        }
    }
    val sel = p.layers.firstOrNull { it.id == state.selectedLayerId }
    if (sel != null) {
        Text("Editing: ${sel.name}", style = MaterialTheme.typography.titleSmall)
        OutlinedButton(onClick = { onReplace(sel.id) }) { Text("Replace image") }
        LabeledSlider("Left-right position", sel.x, -0.25f..1.25f, ::percent) { v ->
            vm.editLayer(sel.id) { it.copy(x = v) }
        }
        LabeledSlider("Up-down position", sel.y, -0.25f..1.25f, ::percent) { v ->
            vm.editLayer(sel.id) { it.copy(y = v) }
        }
        LabeledSlider("Size", sel.scale, 0.1f..2f, ::percent) { v ->
            vm.editLayer(sel.id) { it.copy(scale = v) }
        }
        LabeledSlider("Depth (0 = fixed, 1 = moves most)", sel.depth, 0f..1f) { v ->
            vm.editLayer(sel.id) { it.copy(depth = v) }
        }
        LabeledSlider("Opacity", sel.opacity, 0f..1f, ::percent) { v ->
            vm.editLayer(sel.id) { it.copy(opacity = v) }
        }
    }
}

@Composable
private fun ClockTab(state: EditorState, vm: EditorViewModel, onPickFont: () -> Unit) {
    val c = state.project.clock
    SwitchRow("Show clock", c.enabled) { v -> vm.editClock { it.copy(enabled = v) } }
    SwitchRow("24-hour time", c.use24h) { v -> vm.editClock { it.copy(use24h = v) } }
    SwitchRow("Show date", c.showDate) { v -> vm.editClock { it.copy(showDate = v) } }
    SwitchRow("Put clock behind layers", c.behindLayers) { v -> vm.editClock { it.copy(behindLayers = v) } }
    Text("Font: ${c.fontName ?: "Default"}", style = MaterialTheme.typography.bodyMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onPickFont) { Text("Import font (.ttf / .otf)") }
        if (c.fontFile != null) {
            OutlinedButton(onClick = { vm.clearFont() }) { Text("Use default") }
        }
    }
    ColorField("Text color", c.color) { v -> vm.editClock { it.copy(color = v) } }
    LabeledSlider("Left-right position", c.x, -0.25f..1.25f, ::percent) { v ->
        vm.editClock { it.copy(x = v) }
    }
    LabeledSlider("Up-down position", c.y, -0.25f..1.25f, ::percent) { v ->
        vm.editClock { it.copy(y = v) }
    }
    LabeledSlider("Clock size", c.size, 8f..40f, { "${it.roundToInt()}" }) { v ->
        vm.editClock { it.copy(size = v) }
    }
    LabeledSlider("Date size", c.dateSize, 2f..10f, { "%.1f".format(it) }) { v ->
        vm.editClock { it.copy(dateSize = v) }
    }
    LabeledSlider("Depth", c.depth, 0f..1f) { v -> vm.editClock { it.copy(depth = v) } }
}

@Composable
private fun MotionTab(state: EditorState, vm: EditorViewModel) {
    val p = state.project
    SwitchRow("Tilt motion (uses the motion sensor; turn off to save battery)", p.tilt) { v ->
        vm.edit { it.copy(tilt = v) }
    }
    LabeledSlider("Overall depth strength", p.strength, 0f..2f) { v -> vm.edit { it.copy(strength = v) } }
    Text(
        "Each layer moves by its own Depth setting. In the preview, drag a finger over the picture to test it. " +
            "On the home screen the effect also follows swiping between home pages. " +
            "The animation only runs while something is moving, so a still wallpaper uses almost no power.",
        style = MaterialTheme.typography.bodySmall,
    )
}

// ---------------------------------------------------------------- small widgets

private fun percent(v: Float): String = "${(v * 100).roundToInt()}%"

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: (Float) -> String = { "%.2f".format(it) },
    onChange: (Float) -> Unit,
) {
    Column {
        Text("$label: ${valueText(value)}", style = MaterialTheme.typography.labelLarge)
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private val swatches = listOf(
    "#FFFFFF", "#000000", "#FF5252", "#FFB74D", "#FFEE58", "#66BB6A", "#4FC3F7", "#BA68C8",
)

private fun parseColor(hex: String): Color =
    try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (e: Exception) {
        Color.Gray
    }

private fun isHex(s: String): Boolean = Regex("^#[0-9A-Fa-f]{6}$").matches(s)

@Composable
private fun ColorField(label: String, hex: String, onChange: (String) -> Unit) {
    var text by remember(hex) { mutableStateOf(hex) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(parseColor(hex))
                    .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
            )
            OutlinedTextField(
                value = text,
                onValueChange = { v ->
                    text = v
                    if (isHex(v)) onChange(v.uppercase())
                },
                singleLine = true,
                label = { Text("#RRGGBB") },
                modifier = Modifier.weight(1f),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            swatches.forEach { sw ->
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(parseColor(sw))
                        .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                        .clickable {
                            text = sw
                            onChange(sw)
                        },
                )
            }
        }
    }
}
