package com.loomview.app.ui.maker

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.loomview.app.maker.ClockModel
import com.loomview.app.maker.LayerModel
import com.loomview.app.maker.Project
import com.loomview.app.maker.ProjectStore
import com.loomview.app.maker.WallpaperApplier
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class EditorState(
    val project: Project,
    /** Goes up whenever images or the font change, which needs a full preview reload. */
    val assetsVersion: Int = 0,
    val selectedLayerId: String? = null,
    val busy: Boolean = false,
    val message: String? = null,
    val dirty: Boolean = false,
)

@HiltViewModel
class EditorViewModel @Inject constructor(
    private val store: ProjectStore,
    private val applier: WallpaperApplier,
) : ViewModel() {

    private val _state = MutableStateFlow(EditorState(project = store.newProject()))
    val state: StateFlow<EditorState> = _state.asStateFlow()
    private var started = false

    /** Call once from the Activity. A null id means "create a new project". */
    fun start(projectId: String?) {
        if (started) return
        started = true
        val loaded = projectId?.let { runCatching { store.load(it) }.getOrNull() }
        if (loaded != null) {
            _state.value = EditorState(
                project = loaded,
                selectedLayerId = loaded.layers.firstOrNull()?.id,
            )
        }
    }

    // ------------------------------------------------------------- simple edits

    fun edit(change: (Project) -> Project) {
        _state.update { it.copy(project = change(it.project), dirty = true) }
    }

    fun editClock(change: (ClockModel) -> ClockModel) {
        edit { it.copy(clock = change(it.clock)) }
    }

    fun editLayer(id: String, change: (LayerModel) -> LayerModel) {
        edit { p -> p.copy(layers = p.layers.map { if (it.id == id) change(it) else it }) }
    }

    fun selectLayer(id: String?) {
        _state.update { it.copy(selectedLayerId = id) }
    }

    private fun editAssets(change: (Project) -> Project) {
        _state.update {
            it.copy(
                project = change(it.project),
                dirty = true,
                assetsVersion = it.assetsVersion + 1,
            )
        }
    }

    fun clearBackground() = editAssets { it.copy(bgFile = null) }

    fun clearFont() = editAssets { it.copy(clock = it.clock.copy(fontFile = null, fontName = null)) }

    fun removeLayer(id: String) {
        _state.update { s ->
            val layers = s.project.layers.filter { it.id != id }
            s.copy(
                project = s.project.copy(layers = layers),
                selectedLayerId = if (s.selectedLayerId == id) layers.lastOrNull()?.id else s.selectedLayerId,
                dirty = true,
                assetsVersion = s.assetsVersion + 1,
            )
        }
    }

    /** delta = -1 moves the layer down (further back), +1 moves it up (closer to the front). */
    fun moveLayer(id: String, delta: Int) {
        edit { p ->
            val list = p.layers.toMutableList()
            val i = list.indexOfFirst { it.id == id }
            val j = i + delta
            if (i < 0 || j < 0 || j >= list.size) {
                p
            } else {
                val item = list.removeAt(i)
                list.add(j, item)
                p.copy(layers = list)
            }
        }
    }

    // ------------------------------------------------------------------ imports

    fun setBackground(uri: Uri) = runBusy("Could not import that image") {
        val rel = store.importImage(_state.value.project.id, uri, asBackground = true)
        editAssets { it.copy(bgFile = rel) }
    }

    fun addLayer(uri: Uri) = runBusy("Could not import that image") {
        val p = _state.value.project
        val rel = store.importImage(p.id, uri, asBackground = false)
        val id = "l" + java.lang.Long.toString(System.currentTimeMillis(), 36)
        val layer = LayerModel(id = id, name = "Layer ${p.layers.size + 1}", file = rel)
        _state.update {
            it.copy(
                project = it.project.copy(layers = it.project.layers + layer),
                selectedLayerId = id,
                dirty = true,
                assetsVersion = it.assetsVersion + 1,
            )
        }
    }

    fun replaceLayerImage(layerId: String, uri: Uri) = runBusy("Could not import that image") {
        val rel = store.importImage(_state.value.project.id, uri, asBackground = false)
        editAssets { p ->
            p.copy(layers = p.layers.map { if (it.id == layerId) it.copy(file = rel) else it })
        }
    }

    fun setFont(uri: Uri) = runBusy("Could not import that font") {
        val (rel, name) = store.importFont(_state.value.project.id, uri)
        editAssets { it.copy(clock = it.clock.copy(fontFile = rel, fontName = name)) }
    }

    // ------------------------------------------------------- save / export / apply

    /** Saves if there are unsaved changes. Small JSON write, so it is done directly. */
    fun saveNow(): Boolean {
        val s = _state.value
        if (!s.dirty) return false
        return try {
            val saved = store.save(s.project)
            _state.update { it.copy(project = it.project.copy(modified = saved.modified), dirty = false) }
            true
        } catch (e: Exception) {
            _state.update { it.copy(message = "Could not save: ${e.message}") }
            false
        }
    }

    fun saveWithMessage() {
        if (saveNow()) {
            _state.update { it.copy(message = "Saved") }
        } else if (!_state.value.dirty) {
            _state.update { it.copy(message = "Already saved") }
        }
    }

    fun export(target: Uri) = runBusy("Export failed") {
        saveNow()
        store.exportZip(_state.value.project, target)
        _state.update { it.copy(message = "Exported") }
    }

    fun applyWallpaper(onReady: () -> Unit) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            try {
                saveNow()
                applier.publishAndSet(_state.value.project)
                onReady()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(message = "Could not apply: ${e.message}") }
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    fun messageShown() {
        _state.update { it.copy(message = null) }
    }

    private fun runBusy(fallback: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(message = e.message ?: fallback) }
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }
}
