package com.loomview.app.ui.maker

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loomview.app.data.datastore.SettingsDataStore
import com.loomview.app.maker.Project
import com.loomview.app.maker.launchWallpaperChooser
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/** "My Wallpapers": the list of saved projects. */
@AndroidEntryPoint
class ProjectsActivity : ComponentActivity() {

    private val vm: ProjectsViewModel by viewModels()

    @Inject
    lateinit var settingsDataStore: SettingsDataStore

    private var exportProject: Project? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val createExport = registerForActivityResult(
            ActivityResultContracts.CreateDocument("application/zip"),
        ) { uri ->
            val p = exportProject
            if (uri != null && p != null) vm.export(p, uri)
        }

        setContent {
            MakerTheme(settingsDataStore) {
                val projects by vm.projects.collectAsStateWithLifecycle()
                val message by vm.message.collectAsStateWithLifecycle()
                LaunchedEffect(message) {
                    val m = message
                    if (m != null) {
                        Toast.makeText(this@ProjectsActivity, m, Toast.LENGTH_SHORT).show()
                        vm.messageShown()
                    }
                }
                ProjectsScreen(
                    projects = projects,
                    thumbnail = { vm.thumbnail(it) },
                    onBack = { finish() },
                    onEdit = { p ->
                        startActivity(
                            Intent(this@ProjectsActivity, EditorActivity::class.java)
                                .putExtra(EditorActivity.EXTRA_PROJECT_ID, p.id),
                        )
                    },
                    onApply = { p ->
                        vm.applyWallpaper(p) {
                            Toast.makeText(
                                this@ProjectsActivity,
                                "Choose \"Set wallpaper\" on the next screen",
                                Toast.LENGTH_LONG,
                            ).show()
                            launchWallpaperChooser(this@ProjectsActivity)
                        }
                    },
                    onExport = { p ->
                        exportProject = p
                        val name = p.name.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifEmpty { "wallpaper" }
                        createExport.launch("$name.zip")
                    },
                    onDelete = { p -> vm.delete(p.id) },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }
}
