package com.loomview.app.maker

import org.json.JSONArray
import org.json.JSONObject

/**
 * Wallpaper Maker data model (added on top of the original Loomview app).
 * A project lives in filesDir/projects/<id>/ as project.json + images/ + fonts/.
 * All positions are fractions of the screen so the preview matches the real wallpaper.
 */
data class LayerModel(
    val id: String,
    val name: String,
    val file: String,            // relative to the project folder, e.g. "images/layer_ab12.png"
    val x: Float = 0.5f,         // centre, 0..1 of screen width
    val y: Float = 0.5f,         // centre, 0..1 of screen height
    val scale: Float = 0.8f,     // width as a fraction of screen width
    val depth: Float = 0.6f,     // 0 = fixed, 1 = moves most
    val opacity: Float = 1f,
    val visible: Boolean = true,
)

data class ClockModel(
    val enabled: Boolean = true,
    val x: Float = 0.5f,
    val y: Float = 0.28f,
    val size: Float = 22f,       // clock text size, % of screen width
    val dateSize: Float = 5f,    // date text size, % of screen width
    val color: String = "#FFFFFF",
    val fontFile: String? = null,
    val fontName: String? = null,
    val use24h: Boolean = true,
    val showDate: Boolean = true,
    val behindLayers: Boolean = false,
    val depth: Float = 0.2f,
)

data class Project(
    val id: String,
    val name: String,
    val created: Long,
    val modified: Long,
    val bgFile: String? = null,
    val bgColor: String = "#101820",
    val bgZoom: Float = 1.12f,
    val bgFocusX: Float = 0.5f,
    val bgFocusY: Float = 0.5f,
    val bgDepth: Float = 0.3f,
    val tilt: Boolean = true,
    val strength: Float = 1f,
    val layers: List<LayerModel> = emptyList(),
    val clock: ClockModel = ClockModel(),
)

private fun Float.d(): Double = Math.round(this * 1000f) / 1000.0

private fun JSONObject.f(key: String, def: Float): Float = optDouble(key, def.toDouble()).toFloat()

private fun JSONObject.s(key: String): String? =
    if (isNull(key)) null else optString(key, "").ifEmpty { null }

fun Project.toJson(): JSONObject {
    val o = JSONObject()
    o.put("version", 1)
    o.put("id", id)
    o.put("name", name)
    o.put("created", created)
    o.put("modified", modified)
    o.put("bgFile", bgFile ?: "")
    o.put("bgColor", bgColor)
    o.put("bgZoom", bgZoom.d())
    o.put("bgFocusX", bgFocusX.d())
    o.put("bgFocusY", bgFocusY.d())
    o.put("bgDepth", bgDepth.d())
    o.put("tilt", tilt)
    o.put("strength", strength.d())
    val arr = JSONArray()
    for (l in layers) {
        val lo = JSONObject()
        lo.put("id", l.id)
        lo.put("name", l.name)
        lo.put("file", l.file)
        lo.put("x", l.x.d())
        lo.put("y", l.y.d())
        lo.put("scale", l.scale.d())
        lo.put("depth", l.depth.d())
        lo.put("opacity", l.opacity.d())
        lo.put("visible", l.visible)
        arr.put(lo)
    }
    o.put("layers", arr)
    val c = JSONObject()
    c.put("enabled", clock.enabled)
    c.put("x", clock.x.d())
    c.put("y", clock.y.d())
    c.put("size", clock.size.d())
    c.put("dateSize", clock.dateSize.d())
    c.put("color", clock.color)
    c.put("fontFile", clock.fontFile ?: "")
    c.put("fontName", clock.fontName ?: "")
    c.put("use24h", clock.use24h)
    c.put("showDate", clock.showDate)
    c.put("behindLayers", clock.behindLayers)
    c.put("depth", clock.depth.d())
    o.put("clock", c)
    return o
}

fun projectFromJson(o: JSONObject): Project {
    val layers = ArrayList<LayerModel>()
    val arr = o.optJSONArray("layers")
    if (arr != null) {
        for (i in 0 until arr.length()) {
            val lo = arr.getJSONObject(i)
            layers.add(
                LayerModel(
                    id = lo.getString("id"),
                    name = lo.optString("name", "Layer ${i + 1}"),
                    file = lo.getString("file"),
                    x = lo.f("x", 0.5f),
                    y = lo.f("y", 0.5f),
                    scale = lo.f("scale", 0.8f),
                    depth = lo.f("depth", 0.6f),
                    opacity = lo.f("opacity", 1f),
                    visible = lo.optBoolean("visible", true),
                ),
            )
        }
    }
    val co = o.optJSONObject("clock") ?: JSONObject()
    val clock = ClockModel(
        enabled = co.optBoolean("enabled", true),
        x = co.f("x", 0.5f),
        y = co.f("y", 0.28f),
        size = co.f("size", 22f),
        dateSize = co.f("dateSize", 5f),
        color = co.optString("color", "#FFFFFF"),
        fontFile = co.s("fontFile"),
        fontName = co.s("fontName"),
        use24h = co.optBoolean("use24h", true),
        showDate = co.optBoolean("showDate", true),
        behindLayers = co.optBoolean("behindLayers", false),
        depth = co.f("depth", 0.2f),
    )
    return Project(
        id = o.getString("id"),
        name = o.optString("name", "Wallpaper"),
        created = o.optLong("created", System.currentTimeMillis()),
        modified = o.optLong("modified", System.currentTimeMillis()),
        bgFile = o.s("bgFile"),
        bgColor = o.optString("bgColor", "#101820"),
        bgZoom = o.f("bgZoom", 1.12f),
        bgFocusX = o.f("bgFocusX", 0.5f),
        bgFocusY = o.f("bgFocusY", 0.5f),
        bgDepth = o.f("bgDepth", 0.3f),
        tilt = o.optBoolean("tilt", true),
        strength = o.f("strength", 1f),
        layers = layers,
        clock = clock,
    )
}

/**
 * The small JSON the renderer page (assets/maker/template.html) understands.
 * When [forPublish] is true, hidden layers are left out entirely to keep the file small.
 */
fun Project.toRenderConfig(forPublish: Boolean): JSONObject {
    val o = JSONObject()
    o.put("bgColor", bgColor)
    o.put("hasBg", bgFile != null)
    o.put("zoom", bgZoom.d())
    o.put("fx", bgFocusX.d())
    o.put("fy", bgFocusY.d())
    o.put("bgDepth", bgDepth.d())
    o.put("tilt", tilt)
    o.put("strength", strength.d())
    val arr = JSONArray()
    for (l in layers) {
        if (forPublish && !l.visible) continue
        val lo = JSONObject()
        lo.put("id", l.id)
        lo.put("x", l.x.d())
        lo.put("y", l.y.d())
        lo.put("scale", l.scale.d())
        lo.put("depth", l.depth.d())
        lo.put("opacity", l.opacity.d())
        lo.put("visible", l.visible)
        arr.put(lo)
    }
    o.put("layers", arr)
    val c = JSONObject()
    c.put("enabled", clock.enabled)
    c.put("x", clock.x.d())
    c.put("y", clock.y.d())
    c.put("size", clock.size.d())
    c.put("dateSize", clock.dateSize.d())
    c.put("color", clock.color)
    c.put("hasFont", clock.fontFile != null)
    c.put("h24", clock.use24h)
    c.put("date", clock.showDate)
    c.put("behind", clock.behindLayers)
    c.put("depth", clock.depth.d())
    o.put("clock", c)
    return o
}
