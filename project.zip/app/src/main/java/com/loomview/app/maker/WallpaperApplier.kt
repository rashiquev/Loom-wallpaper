package com.loomview.app.maker

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.loomview.app.data.datastore.SettingsDataStore
import com.loomview.app.wallpaper.LoomviewLiveWallpaper
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Publishes a project as the current Loomview wallpaper page.
 * Uses the same mechanism as the original "Set as Wallpaper" flow: save the page URL in
 * SettingsDataStore (the engine watches it), then open Android's own wallpaper screen.
 */
@Singleton
class WallpaperApplier @Inject constructor(
    private val store: ProjectStore,
    private val settings: SettingsDataStore,
) {
    suspend fun publishAndSet(project: Project) {
        val url = store.publish(project)
        settings.setWallpaperUri(url)
        // Only delete older pages after the new URL is saved, so a running engine never
        // tries to reload a file that has just disappeared.
        store.pruneLive(url)
    }
}

/** Opens Android's normal live-wallpaper preview / apply screen for Loomview. */
fun launchWallpaperChooser(context: Context) {
    val component = ComponentName(context, LoomviewLiveWallpaper::class.java)
    val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
        putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        // Some phones lack the direct screen; fall back to the general live wallpaper list.
        val fallback = Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(fallback)
    }
}
