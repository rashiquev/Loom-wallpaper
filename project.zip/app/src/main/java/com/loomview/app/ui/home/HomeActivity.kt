package com.loomview.app.ui.home

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.loomview.app.data.datastore.SettingsDataStore
import com.loomview.app.ui.browser.BrowserActivity
import com.loomview.app.ui.maker.EditorActivity
import com.loomview.app.ui.maker.MakerTheme
import com.loomview.app.ui.maker.ProjectsActivity
import com.loomview.app.ui.settings.SettingsActivity
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * New launcher screen. The original file browser (BrowserActivity) is still there and is
 * reachable from the "HTML Library" button, so every original Loomview feature is kept.
 */
@AndroidEntryPoint
class HomeActivity : ComponentActivity() {

    @Inject
    lateinit var settingsDataStore: SettingsDataStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MakerTheme(settingsDataStore) {
                HomeScreen(
                    onCreate = { startActivity(Intent(this, EditorActivity::class.java)) },
                    onMyWallpapers = { startActivity(Intent(this, ProjectsActivity::class.java)) },
                    onSettings = { startActivity(Intent(this, SettingsActivity::class.java)) },
                    onLibrary = { startActivity(Intent(this, BrowserActivity::class.java)) },
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    onCreate: () -> Unit,
    onMyWallpapers: () -> Unit,
    onSettings: () -> Unit,
    onLibrary: () -> Unit,
) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Loomview", style = MaterialTheme.typography.displaySmall)
            Text(
                "Live Wallpaper Maker",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(40.dp))
            Button(onClick = onCreate, modifier = Modifier.fillMaxWidth().height(60.dp)) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text("  Create Wallpaper")
            }
            Spacer(Modifier.height(14.dp))
            FilledTonalButton(onClick = onMyWallpapers, modifier = Modifier.fillMaxWidth().height(60.dp)) {
                Icon(Icons.Filled.Folder, contentDescription = null)
                Text("  My Wallpapers")
            }
            Spacer(Modifier.height(14.dp))
            FilledTonalButton(onClick = onSettings, modifier = Modifier.fillMaxWidth().height(60.dp)) {
                Icon(Icons.Filled.Settings, contentDescription = null)
                Text("  Settings")
            }
            Spacer(Modifier.height(28.dp))
            OutlinedButton(onClick = onLibrary, modifier = Modifier.fillMaxWidth()) {
                Text("HTML Library (open any .html wallpaper)")
            }
        }
    }
}
