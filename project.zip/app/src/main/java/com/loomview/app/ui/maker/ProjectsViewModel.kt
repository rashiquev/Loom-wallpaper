package com.loomview.app.ui.maker

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.loomview.app.maker.Project
import com.loomview.app.maker.ProjectStore
import com.loomview.app.maker.WallpaperApplier
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

@HiltViewModel
class ProjectsViewModel @Inject constructor(
    private val store: ProjectStore,
    private val applier: WallpaperApplier,
) : ViewModel() {

    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun refresh() {
        viewModelScope.launch {
            _projects.value = withContext(Dispatchers.IO) { store.list() }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.delete(id) }
            refresh()
        }
    }

    fun export(project: Project, target: Uri) {
        viewModelScope.launch {
            try {
                store.exportZip(project, target)
                _message.value = "Exported"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _message.value = "Export failed: ${e.message}"
            }
        }
    }

    fun applyWallpaper(project: Project, onReady: () -> Unit) {
        viewModelScope.launch {
            try {
                applier.publishAndSet(project)
                onReady()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _message.value = "Could not apply: ${e.message}"
            }
        }
    }

    fun thumbnail(project: Project): File? = project.bgFile?.let { store.fileOf(project, it) }

    fun messageShown() {
        _message.value = null
    }
}
