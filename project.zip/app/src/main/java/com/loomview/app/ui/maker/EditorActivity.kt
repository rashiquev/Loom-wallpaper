package com.loomview.app.ui.maker

import android.net.Uri
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Gravity
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.loomview.app.data.datastore.SettingsDataStore
import com.loomview.app.maker.Project
import com.loomview.app.maker.ProjectStore
import com.loomview.app.maker.launchWallpaperChooser
import com.loomview.app.maker.toRenderConfig
import com.loomview.app.util.applyLoomviewBaseSettings
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

/**
 * Wallpaper Maker editor: live preview on top, controls underneath.
 *
 * Follows the same rule as ViewerActivity: the WebView is a plain View in a LinearLayout, and
 * only the controls live in a ComposeView. The WebView is NOT wrapped in Compose's AndroidView.
 */
@AndroidEntryPoint
class EditorActivity : ComponentActivity() {

    private val vm: EditorViewModel by viewModels()

    @Inject
    lateinit var settingsDataStore: SettingsDataStore

    @Inject
    lateinit var store: ProjectStore

    private lateinit var webView: WebView
    private var pageReady = false
    private var loadedVersion = -1
    private var buildJob: Job? = null
    private var previewFile: File? = null
    private var pendingReplaceLayerId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm.start(intent.getStringExtra(EXTRA_PROJECT_ID))

        // Leftovers from a previous run
        cacheDir.listFiles { f -> f.name.startsWith("maker_preview_") }?.forEach { it.delete() }

        val pickBackground = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.setBackground(uri)
        }
        val pickLayer = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.addLayer(uri)
        }
        val pickReplace = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val id = pendingReplaceLayerId
            if (uri != null && id != null) vm.replaceLayerImage(id, uri)
        }
        val pickFont = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.setFont(uri)
        }
        val createExport = registerForActivityResult(
            ActivityResultContracts.CreateDocument("application/zip"),
        ) { uri ->
            if (uri != null) vm.export(uri)
        }

        // Preview box with the same shape as the real screen, so what you see is what you get.
        val screen = realScreenSize()
        val previewH = (screen.second * 0.40f).toInt()
        val previewW = (previewH * screen.first.toFloat() / screen.second).toInt()

        webView = WebView(this).apply {
            applyLoomviewBaseSettings(isWallpaperMode = false)
            settings.minimumFontSize = 1
            settings.minimumLogicalFontSize = 1
            layoutParams = FrameLayout.LayoutParams(previewW, previewH, Gravity.CENTER_HORIZONTAL)
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    pageReady = true
                    pushConfig(vm.state.value.project)
                }
            }
        }
        val previewFrame = FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            addView(webView)
        }

        val controls = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                MakerTheme(settingsDataStore) {
                    val state by vm.state.collectAsStateWithLifecycle()
                    LaunchedEffect(state.message) {
                        val msg = state.message
                        if (msg != null) {
                            Toast.makeText(this@EditorActivity, msg, Toast.LENGTH_SHORT).show()
                            vm.messageShown()
                        }
                    }
                    EditorPanel(
                        state = state,
                        vm = vm,
                        onPickBackground = { pickBackground.launch(arrayOf("image/*")) },
                        onPickLayer = { pickLayer.launch(arrayOf("image/png", "image/*")) },
                        onReplaceLayer = { id ->
                            pendingReplaceLayerId = id
                            pickReplace.launch(arrayOf("image/png", "image/*"))
                        },
                        onPickFont = { pickFont.launch(arrayOf("*/*")) },
                        onSave = { vm.saveWithMessage() },
                        onExport = {
                            val name = vm.state.value.project.name
                                .replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifEmpty { "wallpaper" }
                            createExport.launch("$name.zip")
                        },
                        onApply = {
                            vm.applyWallpaper {
                                Toast.makeText(
                                    this@EditorActivity,
                                    "Choose \"Set wallpaper\" on the next screen",
                                    Toast.LENGTH_LONG,
                                ).show()
                                launchWallpaperChooser(this@EditorActivity)
                            }
                        },
                    )
                }
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            addView(
                previewFrame,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, previewH),
            )
            addView(
                controls,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f),
            )
        }
        setContentView(root)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    /**
     * Images/fonts changed -> rebuild the page and reload it.
     * Only sliders/switches changed -> push the small config into the running page (instant).
     */
    private fun render(s: EditorState) {
        if (s.assetsVersion != loadedVersion) {
            loadedVersion = s.assetsVersion
            pageReady = false
            buildJob?.cancel()
            val snapshot = s.project
            buildJob = lifecycleScope.launch {
                val file = withContext(Dispatchers.IO) {
                    val html = store.buildHtml(snapshot, forPublish = false)
                    File(cacheDir, "maker_preview_${System.nanoTime()}.html").also { it.writeText(html) }
                }
                webView.loadUrl(Uri.fromFile(file).toString())
                previewFile?.delete()
                previewFile = file
            }
        } else if (pageReady) {
            pushConfig(s.project)
        }
    }

    private fun pushConfig(p: Project) {
        val json = p.toRenderConfig(forPublish = false).toString()
        webView.evaluateJavascript("window.loomUpdate&&window.loomUpdate($json);", null)
    }

    @Suppress("DEPRECATION")
    private fun realScreenSize(): Pair<Int, Int> {
        val m = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        super.onPause()
        vm.saveNow()
        webView.onPause()
    }

    override fun onDestroy() {
        buildJob?.cancel()
        previewFile?.delete()
        (webView.parent as? android.view.ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PROJECT_ID = "com.loomview.app.EXTRA_PROJECT_ID"
    }
}
