package com.loomview.app.maker

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * File-based storage for Wallpaper Maker projects, plus the HTML builder that turns a
 * project into ONE self-contained HTML page (images and fonts embedded as data: URIs).
 * Self-contained matters because the original Loomview engine just calls
 * WebView.loadUrl(<saved url>) and nothing else.
 */
@Singleton
class ProjectStore @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val projectsRoot: File
        get() = File(context.filesDir, "projects").also { it.mkdirs() }

    private val liveRoot: File
        get() = File(context.filesDir, "live").also { it.mkdirs() }

    private val template: String by lazy {
        context.assets.open("maker/template.html").bufferedReader().use { it.readText() }
    }

    fun dir(id: String): File = File(projectsRoot, id)

    fun fileOf(project: Project, relative: String): File = File(dir(project.id), relative)

    // ---------------------------------------------------------------- projects

    fun newProject(): Project {
        val now = System.currentTimeMillis()
        val label = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(now))
        return Project(
            id = UUID.randomUUID().toString().replace("-", "").take(10),
            name = "Wallpaper $label",
            created = now,
            modified = now,
        )
    }

    fun list(): List<Project> =
        (projectsRoot.listFiles() ?: emptyArray<File>())
            .filter { it.isDirectory }
            .mapNotNull { runCatching { load(it.name) }.getOrNull() }
            .sortedByDescending { it.modified }

    fun load(id: String): Project {
        val text = File(dir(id), "project.json").readText()
        return projectFromJson(JSONObject(text))
    }

    /** Writes project.json and removes image/font files the project no longer uses. */
    fun save(project: Project): Project {
        val saved = project.copy(modified = System.currentTimeMillis())
        val d = dir(saved.id)
        d.mkdirs()
        val tmp = File(d, "project.json.tmp")
        tmp.writeText(saved.toJson().toString(2))
        val target = File(d, "project.json")
        if (!tmp.renameTo(target)) {
            target.writeText(tmp.readText())
            tmp.delete()
        }
        pruneUnused(saved)
        return saved
    }

    fun delete(id: String) {
        dir(id).deleteRecursively()
    }

    private fun pruneUnused(p: Project) {
        val used = HashSet<String>()
        p.bgFile?.let { used.add(it) }
        p.layers.forEach { used.add(it.file) }
        p.clock.fontFile?.let { used.add(it) }
        for (sub in listOf("images", "fonts")) {
            File(dir(p.id), sub).listFiles()?.forEach { f ->
                if (!used.contains("$sub/${f.name}")) f.delete()
            }
        }
    }

    // ----------------------------------------------------------------- imports

    /** Copies an image from the gallery into the project, downscaled (and EXIF-rotated). */
    suspend fun importImage(projectId: String, uri: Uri, asBackground: Boolean): String =
        withContext(Dispatchers.IO) {
            val maxDim = if (asBackground) 2048 else 1600
            val bmp = decodeScaled(uri, maxDim) ?: throw IOException("Could not read that image")
            val imagesDir = File(dir(projectId), "images").also { it.mkdirs() }
            val stamp = java.lang.Long.toString(System.currentTimeMillis(), 36)
            val name = if (asBackground) "bg_$stamp.jpg" else "layer_$stamp.png"
            File(imagesDir, name).outputStream().use { out ->
                if (asBackground) {
                    bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
                } else {
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
            }
            bmp.recycle()
            "images/$name"
        }

    /** Copies a .ttf/.otf font into the project. Returns (relative path, display name). */
    suspend fun importFont(projectId: String, uri: Uri): Pair<String, String> =
        withContext(Dispatchers.IO) {
            val displayName = queryName(uri) ?: "font"
            val lower = displayName.lowercase(Locale.ROOT)
            if (!lower.endsWith(".ttf") && !lower.endsWith(".otf")) {
                throw IOException("Please choose a .ttf or .otf font file")
            }
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IOException("Could not read that font file")
            if (bytes.size > 12 * 1024 * 1024) throw IOException("That font is larger than 12 MB")
            if (bytes.size < 12) throw IOException("That file is not a valid font")
            val magic = String(bytes, 0, 4, Charsets.ISO_8859_1)
            val isOtf = magic == "OTTO"
            val isTtf = magic == "true" ||
                (bytes[0].toInt() == 0 && bytes[1].toInt() == 1 && bytes[2].toInt() == 0 && bytes[3].toInt() == 0)
            if (!isOtf && !isTtf) throw IOException("That file does not look like a valid font")
            val fontsDir = File(dir(projectId), "fonts").also { it.mkdirs() }
            val ext = if (isOtf) "otf" else "ttf"
            val name = "font_${java.lang.Long.toString(System.currentTimeMillis(), 36)}.$ext"
            File(fontsDir, name).writeBytes(bytes)
            Pair("fonts/$name", displayName.substringBeforeLast('.'))
        }

    private fun queryName(uri: Uri): String? {
        var name: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0)
                }
        } catch (e: Exception) {
            // fall through to lastPathSegment
        }
        return name ?: uri.lastPathSegment
    }

    private fun decodeScaled(uri: Uri, maxDim: Int): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxDim) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null
        val rotation = try {
            resolver.openInputStream(uri)?.use { exifRotation(it) } ?: 0
        } catch (e: Exception) {
            0
        }
        val longest = maxOf(bmp.width, bmp.height)
        val scale = if (longest > maxDim) maxDim.toFloat() / longest else 1f
        if (scale < 1f || rotation != 0) {
            val m = Matrix()
            if (rotation != 0) m.postRotate(rotation.toFloat())
            if (scale < 1f) m.postScale(scale, scale)
            val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (out !== bmp) bmp.recycle()
            bmp = out
        }
        return bmp
    }

    private fun exifRotation(stream: InputStream): Int {
        val exif = android.media.ExifInterface(stream)
        return when (
            exif.getAttributeInt(
                android.media.ExifInterface.TAG_ORIENTATION,
                android.media.ExifInterface.ORIENTATION_NORMAL,
            )
        ) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    }

    // -------------------------------------------------------------- HTML build

    private fun dataUri(file: File, mime: String): String =
        "data:$mime;base64," + Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)

    private fun imageMime(name: String): String = when {
        name.endsWith(".png", true) -> "image/png"
        name.endsWith(".webp", true) -> "image/webp"
        else -> "image/jpeg"
    }

    /** Builds the complete, self-contained HTML page for a project. */
    fun buildHtml(project: Project, forPublish: Boolean): String {
        val assets = JSONObject()
        project.bgFile?.let { rel ->
            val f = fileOf(project, rel)
            if (f.exists()) assets.put("bg", dataUri(f, imageMime(rel)))
        }
        for (l in project.layers) {
            if (forPublish && !l.visible) continue
            val f = fileOf(project, l.file)
            if (f.exists()) assets.put(l.id, dataUri(f, imageMime(l.file)))
        }
        var fontCss = ""
        project.clock.fontFile?.let { rel ->
            val f = fileOf(project, rel)
            if (f.exists()) {
                val isOtf = rel.endsWith(".otf", true)
                val mime = if (isOtf) "font/otf" else "font/ttf"
                val format = if (isOtf) "opentype" else "truetype"
                fontCss = "@font-face{font-family:'LoomClock';src:url(" + dataUri(f, mime) +
                    ") format('" + format + "');}"
            }
        }
        val config = project.toRenderConfig(forPublish)
        return template
            .replace("/*__FONT_CSS__*/", fontCss)
            .replace("/*__ASSETS__*/{}", assets.toString())
            .replace("/*__CONFIG__*/{}", config.toString())
    }

    // ----------------------------------------------------------------- publish

    /**
     * Writes the wallpaper page to filesDir/live/ under a NEW name each time and returns its
     * file:// URL. A new URL is needed because the Loomview engine only reloads its WebView
     * when the saved URL string changes.
     */
    suspend fun publish(project: Project): String = withContext(Dispatchers.IO) {
        val html = buildHtml(project, forPublish = true)
        val f = File(liveRoot, "${project.id}-${System.currentTimeMillis()}.html")
        f.writeText(html)
        Uri.fromFile(f).toString()
    }

    /** Deletes older published pages once the new URL has been saved. */
    fun pruneLive(keepUrl: String) {
        liveRoot.listFiles()?.forEach { f ->
            if (Uri.fromFile(f).toString() != keepUrl) f.delete()
        }
    }

    // ------------------------------------------------------------------ export

    /** Writes a zip with project.json, wallpaper.html, images/ and fonts/. */
    suspend fun exportZip(project: Project, target: Uri) = withContext(Dispatchers.IO) {
        val root = project.name.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifEmpty { "wallpaper" }
        val out = context.contentResolver.openOutputStream(target)
            ?: throw IOException("Could not write to that location")
        ZipOutputStream(BufferedOutputStream(out)).use { zip ->
            fun putBytes(name: String, bytes: ByteArray) {
                zip.putNextEntry(ZipEntry("$root/$name"))
                zip.write(bytes)
                zip.closeEntry()
            }
            putBytes("project.json", project.toJson().toString(2).toByteArray(Charsets.UTF_8))
            putBytes("wallpaper.html", buildHtml(project, forPublish = true).toByteArray(Charsets.UTF_8))
            putBytes(
                "README.txt",
                ("Loomview Wallpaper Maker project: ${project.name}\n" +
                    "wallpaper.html is a complete, self-contained page. Open it with Loomview's HTML library " +
                    "or any browser. images/ and fonts/ hold the original source files.\n")
                    .toByteArray(Charsets.UTF_8),
            )
            val rels = ArrayList<String>()
            project.bgFile?.let { rels.add(it) }
            project.layers.forEach { rels.add(it.file) }
            project.clock.fontFile?.let { rels.add(it) }
            for (rel in rels) {
                val f = fileOf(project, rel)
                if (!f.exists()) continue
                zip.putNextEntry(ZipEntry("$root/$rel"))
                f.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }
}
